import os

SECRET_KEY = '4178a256-f17d-45b4-abd9-3cf9a4752f05'
#DB = 'postgresql://postgres:postgres@localhost/db_flask'
basedir = os.path.abspath(os.path.dirname(__file__))
DB = 'sqlite:///' + os.path.join(basedir, 'flask.db')